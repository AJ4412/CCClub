import Head from "next/head";
import Image from "next/image";
import styles from "../styles/Home.module.css";
import Home1 from "../components/Home";

export default function Home() {
  return <Home1 />;
}
`
npm i axios@0.27.2 bootstrap@3.4.1 ethers@5.6.8 jwt-decode@3.1.2 react-hot-toast@2.2.0

`;
